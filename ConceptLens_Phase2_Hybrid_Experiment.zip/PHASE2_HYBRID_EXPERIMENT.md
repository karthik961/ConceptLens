# ConceptLens Phase 2 — controlled hybrid retrieval experiment

This patch **does not alter the existing Streamlit app, semantic retriever, Chroma index, BEETLE data, or original benchmark files.** It adds a small-corpus experimental retriever and a separate evaluation/audit workflow. No new dependencies.

## Install

Copy these files into the *existing* `ConceptLens_Starter2` project, retaining their paths:

- `src/hybrid_retrieval.py`
- `scripts/evaluate_hybrid.py`
- `scripts/audit_hybrid.py`

The existing `scripts/audit_retrieval.py` from the previous step must still be in place.

## Run

```bash
cd /path/to/ConceptLens_Starter2
source .venv/bin/activate
python -m scripts.evaluate_hybrid
python -m scripts.audit_hybrid prepare
```

Open `eval/retrieval_audit_hybrid.csv` and review all 3 retrieved sources per query. Some entries are prefilled **only** if the case ID, query, filename, and complete passage text match your existing worksheet. **Fill remaining blank relevance (0/1/2) and rationale fields**, inspect the prefilled entries, and save CSV.

```bash
python -m scripts.audit_hybrid score
```

Check `eval/retrieval_audit_hybrid_report.json` and compare to `eval/retrieval_audit_report.json`:

| Method | Hit@3 | MRR@3 | Precision@3 | Notes |
|---|---|---|---|---|
| Semantic-only (original) | 0.975 | 0.867 | 0.425 | AI-assisted relevance audit |
| Hybrid (experimental) | *run audit* | *run audit* | *run audit* | Must re-review new candidate passages |

For R032, inspect whether the retrieval includes `computer_science/03_data_structures.md` and whether the **selected chunk** contains the FIFO-vs-LIFO explanation. This experiment tries an index-wide lexical BM25 signal plus semantic search and equal-weight score blending (normalized BM25 and semantic ranks). Unlike a phrase-specific rule, it applies to every question, and **might improve some queries while degrading others**. Compare aggregate metrics, not just R032.

## Important limits

1. This implementation reads the subject-matched chunks from Chroma for each query and computes BM25 in Python. That's reasonable for this 32-note dataset, but does not scale to large knowledge bases. No change is needed to your existing `.chromadb` database.
2. The development questions and the educational notes are both project-authored. Do not use the 40-query performance as an independent blind result.
3. BM25 includes general FIFO/LIFO abbreviation expansion. This is an explicit feature choice motivated by the development-set diagnosis. Final claims require a **separately created and frozen held-out question set**.
4. The hybrid method is not connected to the Streamlit app yet. Switch it on only after fair evaluation. Retrieval is separate from feedback accuracy.
5. Your current relevance labels were AI-assisted and should not be described as independently human-verified unless reviewed by a person.
